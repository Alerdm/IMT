self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "663afa57951d4b0e06b318986dbd46fa",
    "url": "/wp-content/themes/imt_react_app/index.php"
  },
  {
    "revision": "c120c9aae634073c1653",
    "url": "/wp-content/themes/imt_react_app/static/css/2.chunk.css"
  },
  {
    "revision": "14f8f63899149ba0cadd",
    "url": "/wp-content/themes/imt_react_app/static/css/main.chunk.css"
  },
  {
    "revision": "c120c9aae634073c1653",
    "url": "/wp-content/themes/imt_react_app/static/js/2.chunk.js"
  },
  {
    "revision": "90ed098ebc7a603d8aa1c7599329c73a",
    "url": "/wp-content/themes/imt_react_app/static/js/2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "87c29918d5110f27a825",
    "url": "/wp-content/themes/imt_react_app/static/js/bundle.js"
  },
  {
    "revision": "14f8f63899149ba0cadd",
    "url": "/wp-content/themes/imt_react_app/static/js/main.chunk.js"
  }
]);