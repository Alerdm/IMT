self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c40116832b012c2082c88221960e1ba7",
    "url": "/wp-content/themes/imt_react_app/index.php"
  },
  {
    "revision": "c120c9aae634073c1653",
    "url": "/wp-content/themes/imt_react_app/static/css/2.chunk.css"
  },
  {
    "revision": "9b58de119ecb81f607fc",
    "url": "/wp-content/themes/imt_react_app/static/css/main.chunk.css"
  },
  {
    "revision": "c120c9aae634073c1653",
    "url": "/wp-content/themes/imt_react_app/static/js/2.chunk.js"
  },
  {
    "revision": "90ed098ebc7a603d8aa1c7599329c73a",
    "url": "/wp-content/themes/imt_react_app/static/js/2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "87c29918d5110f27a825",
    "url": "/wp-content/themes/imt_react_app/static/js/bundle.js"
  },
  {
    "revision": "9b58de119ecb81f607fc",
    "url": "/wp-content/themes/imt_react_app/static/js/main.chunk.js"
  }
]);